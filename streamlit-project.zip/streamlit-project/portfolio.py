import streamlit as st
from PIL import Image

# Portfolio - Main Content
def main():
    # Set Page Configuration
    st.set_page_config(page_title="My Portfolio", page_icon="📈", layout="wide")

    # Sidebar Content
    with st.sidebar:
        st.title("👨‍💻 My Portfolio")
        st.image("profile.jpg", caption="Sugumaran", width=150)  # Replace with your profile picture
        st.write("Welcome to my personal portfolio. Explore my work, skills, and contact me!")
        st.markdown("---")
        st.write("📧 Email: sugumaran1102@gmail.com")
        st.write("🔗 [LinkedIn](https://www.linkedin.com)")
        st.write("💻 [GitHub](https://www.github.com)")

    # Main Page Content
    st.title("Hello, I'm Sugumaran B 👋")
    st.subheader("Associate Software Engineer, Data Engineer | Prodapt Solutions] passionate about building impactful projects.")

    # About Me Section
    st.markdown("### 🧑 About Me")
    st.write("""
        I am a passionate [Your Profession/Field] with expertise in [skills].
        My focus is on solving real-world problems using technology and data-driven solutions.
    """)

    # Skills Section
    st.markdown("### ⚒️ Skills")
    skills = ["Python", "Machine Learning", "Data Visualization", "Streamlit", "SQL"]
    for skill in skills:
        st.markdown(f"- {skill}")

    # Projects Section
    st.markdown("### 🚀 Projects")
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Project 1")
        st.image("project1.jpg", caption="Project 1", use_column_width=True)
        st.write("""
        **Description**: A brief description of your first project.
        - 🛠 Tools: Python, Pandas
        - 🌐 [View Project](https://github.com)
        """)
    
    with col2:
        st.subheader("Project 2")
        st.image("project2.jpg", caption="Project 2", use_column_width=True)
        st.write("""
        **Description**: A brief description of your second project.
        - 🛠 Tools: Python, Streamlit
        - 🌐 [View Project](https://github.com)
        """)

    # Contact Section
    st.markdown("### 📞 Contact Me")
    st.write("Feel free to reach out for collaborations or opportunities.")
    contact_form = """
    <form action="https://formsubmit.co/your.email@example.com" method="POST">
         <input type="text" name="name" placeholder="Your Name" required>
         <input type="email" name="email" placeholder="Your Email" required>
         <textarea name="message" placeholder="Your Message" required></textarea>
         <button type="submit">Send</button>
    </form>
    """
    st.markdown(contact_form, unsafe_allow_html=True)

if __name__ == "__main__":
    main()
