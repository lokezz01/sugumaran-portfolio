import streamlit as st
from PIL import Image

# --- General Settings ---
st.set_page_config(page_title="Digital CV", page_icon="🧑‍💻", layout="wide")
hide_streamlit_style = """
    <style>
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}
    </style>
"""
st.markdown(hide_streamlit_style, unsafe_allow_html=True)

# --- Load Images ---
profile_pic = "profile.jpeg "  # Replace with your profile image file
cv_pdf = "resume.pdf"  # Replace with your resume file

# --- Sidebar ---
with st.sidebar:
    st.image(profile_pic, width=150)
    st.title("👋 Hi, I'm Sugumaran")
    st.subheader("Associate Software Engineer | Data Engineer]")
    st.write("""
    - 📧 Email: [sugumaran1102@gmail.com](mailto:sugumaran1102@gmail.com)
    - 🔗 [LinkedIn](https://www.linkedin.com/in/sugumaran-b-a4868a219)
    - 💻 [GitHub](https://github.com/lokezz01)
    - 📄 [Download CV](resume.pdf)
    """)
    st.markdown("---")

# --- Introduction ---
st.title("Digital CV 🧑‍💻")
st.write("""
Welcome to my interactive digital CV!  
Explore my background, skills, projects, and experiences in a single place.
""")

# --- About Me Section ---
st.subheader("About Me")
st.write("""
I'm a Sugumaran/Associate Software Engineer] passionate about creating solutions to real-world problems using technology.  
With expertise in **Python**, **AWS Services**,**SQL**,**PySpark** and **Web Development**, I aim to deliver impactful projects.
""")

# --- Skills Section ---
st.subheader("Skills")
skills = {
    "Programming Languages": ["Python", "JavaScript", "SQL","AWS Services"],
    "Libraries & Frameworks": ["Streamlit", "Pandas", "NumPy", "Matplotlib"],
    "Tools & Platforms": ["Git", "VS Code", "Jupyter", "Docker"],
}
for category, skillset in skills.items():
    st.write(f"**{category}:** {', '.join(skillset)}")

# --- Projects Section ---
st.subheader("Projects")
col1, col2 = st.columns(2)

with col1:
    st.markdown("### 📊 Project 1: Data Dashboard")
    st.image("project1.jpg", caption="Data Dashboard Project", use_column_width=True)
    st.write("""
    - **Tools**: Python, Streamlit, Pandas  
    - **Description**: A dashboard to analyze and visualize data.
    - 🌐 [View Project](https://github.com)
    """)

with col2:
    st.markdown("### 🌐 Project 2: Web Scraper")
    st.image("project2.jpg", caption="Web Scraper Project", use_column_width=True)
    st.write("""
    - **Tools**: Python, BeautifulSoup, Pandas  
    - **Description**: A web scraper to collect real-time data.
    - 🌐 [View Project](https://github.com)
    """)

# --- Work Experience ---
st.subheader("Work Experience")
st.write("""
- **Software Engineer**, ABC Company *(2022 - Present)*  
  - Developed scalable web applications and dashboards.
  - Worked with Python, Streamlit, and cloud technologies.

- **Data Analyst**, XYZ Company *(2020 - 2022)*  
  - Analyzed large datasets and created visualizations for business insights.
  - Tools: Python, SQL, Tableau
""")

# --- Contact Section ---
st.subheader("Contact Me 📞")
contact_form = """
<form action="https://formsubmit.co/your-email@example.com" method="POST">
     <input type="text" name="name" placeholder="Sugumaran B" required>
     <input type="email" name="email" placeholder="sugumaran1102@gmail.com" required>
     <textarea name="message" placeholder="Your Message" required></textarea>
     <button type="submit">Send</button>
</form>
"""
st.markdown(contact_form, unsafe_allow_html=True)
st.write("Feel free to reach out for collaborations or opportunities!")

# --- Footer ---
st.markdown("---")
st.write("🧑‍💻 Created with Streamlit | © 2024 Sugumaram B")
